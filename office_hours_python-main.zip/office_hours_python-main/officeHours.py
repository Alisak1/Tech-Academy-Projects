title = "Office Hour"
print(title)

message = "Office hour are from 9:00 am to 9:00 pm."
print(message)

portlandTime = 8
newYorkTime = 3
londontime = 5

def portlandBranch():
    if portlandTime == 1:
        print("The Portland branch is closed")
    elif portlandTime == 2:
        print("The Portland branch is closed")
    elif portlandTime == 3:
        print("The Portland branch is closed")
    elif portlandTime == 4:
        print("The Portland branch is closed")
    elif portlandTime == 5:
        print("The Portland branch is closed")
    elif portlandTime == 6:
        print("The Portland branch is closed")
    elif portlandTime == 7:
        print("The Portland branch is closed")
    elif portlandTime == 8:
        print("The Portland branch is open")
    elif portlandTime == 9:
        print("The Portland branch is closed")
    elif portlandTime == 10:
        print("The Portland branch is closed")
    elif portlandTime == 11:
        print("The Portland branch is closed")
    elif portlandTime == 12:
        print("The Portland branch is closed")
    else:
        print("An error has occured")

def newYorkBranch():
    if newYorkTime == 1:
        print("The New York branch is closed")
    elif newYorkTime == 2:
        print("The New York branch is closed")
    elif newYorkTime == 3:
        print("The New York branch is open")
    elif newYorkTime == 4:
        print("The New York branch is closed")
    elif newYorkTime == 5:
        print("The New York branch is closed")
    elif newYorkTime == 6:
        print("The New York branch is closed")
    elif newYorkTime == 7:
        print("The New York branch is closed")
    elif newYorkTime == 8:
        print("The New York branch is closed")
    elif newYorkTime == 9:
        print("The New York branch is closed")
    elif newYorkTime == 10:
        print("The New York branch is closed")
    elif newYorkTime == 11:
        print("The New York branch is closed")
    elif newYorkTime == 12:
        print("The New York branch is closed")
    else:
        print("An error has occured")

def londonBranch():
    if londontime == 1:
        print("The London branch is closed")
    elif londontime == 2:
        print("The London branch is closed")
    elif londontime == 3:
        print("The London branch is closed")
    elif londontime == 4:
        print("The London branch is closed")
    elif londontime == 5:
        print("The London branch is open")
    elif londontime == 6:
        print("The London branch is closed")
    elif londontime == 7:
        print("The London branch is closed")
    elif londontime == 8:
        print("The London branch is closed")
    elif londontime == 9:
        print("The London branch is closed")
    elif londontime == 10:
        print("The London branch is closed")
    elif londontime == 11:
        print("The London branch is closed")
    elif londontimee == 12:
        print("The London branch is closed")        
    else:
        print("An error has occured")

portlandBranch()
newYorkBranch()
londonBranch()
