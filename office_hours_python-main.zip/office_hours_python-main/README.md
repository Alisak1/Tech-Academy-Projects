https://github.com/the-tech-academy/office_hours_python.git<dl>
  <dt>Project Name:</dt>
  <dd>office_hours</dd>

  <dt>Project Description:</dt>
  <dd>This is the final drill for the Version Control Course.</dd>

  <dt>Project Intentions:</dt>
  <dd>This drill will demonstrate how developers may remotely collaborate together to complete a project.</dd>
</dl>
